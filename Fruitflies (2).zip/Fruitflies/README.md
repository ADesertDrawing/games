Fruitflies is a game by A Desert Drawing (with lots of help from Pippin Barr).

