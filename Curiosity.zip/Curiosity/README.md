# Template p5 project

Curiosity was originally a Twine game I made (A Desert Drawing / Geraint Edwards) as a micro-commission for Playing Poetry.
I wanted to put it in a wooden computer that I'd built, running on a Raspberry Pi, but it wouldn't work properly.
Pippin Barr was kind enough to rebuild it in HTML which I then fleshed out. 
It was shown at Peckham Digital Festival of Creative Computing in 2024.  
