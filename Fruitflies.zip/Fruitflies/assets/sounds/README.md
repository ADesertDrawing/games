# Sounds folder

The background music is "No Use Crying" by Spencer Adams and his Orchestra (1922). Downloaded from the Internet Archive: https://archive.org/details/78_no-use-crying_spencer-adams-and-orchestra-hirsch_gbia0004841a
