# Sounds folder

The background music is "No Use Crying" by Spencer Adams and his Orchestra (1922). Downloaded from the Internet Archive: https://archive.org/details/78_no-use-crying_spencer-adams-and-orchestra-hirsch_gbia0004841a

Extra static sound is: vinyl_record_needle_static_01.wav by joedeshon -- https://freesound.org/s/140295/ -- License: Attribution 4.0
